﻿using MediatR;
using POS.Data;
using POS.Data.Dto;
using POS.Data.Dto.SalesOrder;
using POS.Helper;
using System;
using System.Collections.Generic;

namespace POS.MediatR.CommandAndQuery
{
    public class AddSalesOrderCommand : IRequest<ServiceResponse<SalesOrderDto>>
    {
        public string OrderNumber { get; set; }
        public string Note { get; set; }
        public string TermAndCondition { get; set; }
        public bool IsSalesOrderRequest { get; set; }
        public DateTime SOCreatedDate { get; set; }
        public SalesOrderStatus Status { get; set; }
        public DateTime DeliveryDate { get; set; }
        public DeliveryStatus DeliveryStatus { get; set; }
        public Guid CustomerId { get; set; }
        //public Guid? ConsigneeId { get; set; }
        public decimal TotalAmount { get; set; }
        public decimal TotalTax { get; set; }
        public decimal TotalDiscount { get; set; }
        public List<SalesOrderItemDto> SalesOrderItems { get; set; }

        // Logistics-specific data
        public bool IsLogisticsOrder { get; set; }
        public SaleOrderDetailDto LogisticsSaleOrderDetail { get; set; }  
        public List<SaleOrderProductsItemsDto> LogisticsSaleOrderProductsItems { get; set; }
    }
}
