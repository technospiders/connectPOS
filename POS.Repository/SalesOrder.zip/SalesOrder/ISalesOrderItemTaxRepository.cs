﻿
using POS.Common.GenericRepository;
using POS.Data;

namespace POS.Repository
{
    public interface ISalesOrderItemTaxRepository : IGenericRepository<SalesOrderItemTax>
    {
    }
}
